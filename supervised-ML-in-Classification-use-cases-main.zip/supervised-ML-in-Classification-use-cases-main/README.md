# supervised-ML-in-Classification-use-cases 
Solved real time case studies of binary and multinomial classification problems by doing analysis of data , Exploratory data analysis , Feature Engineering , Feature Selection and Model building with hyperparameter tuning
